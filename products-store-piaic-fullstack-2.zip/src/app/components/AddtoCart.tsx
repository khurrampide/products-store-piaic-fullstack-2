import React from 'react'

const AddtoCart = () => {
  return (
    <button className='border mr-32 hover:scale-90  transition-transform rounded-md mt-4 bg-green-900 text-white px-2 py-1'> Add to Cart</button>
  )
}

export default AddtoCart